//
//  MyVariable.swift
//  addingTable
//
//  Created by Piotr Suchozebrski on 29/11/2018.
//  Copyright © 2018 Piotr Suchozebrski. All rights reserved.
//

import Foundation

struct MyVariable {
    
 static var myList: [ItemList] = [ItemList(translation:"", itemDescription:"")]
    
}
