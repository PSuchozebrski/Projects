//
//  Constants.swift
//  addingTable
//
//  Created by Piotr Suchozebrski on 16/11/2018.
//  Copyright © 2018 Piotr Suchozebrski. All rights reserved.
//

import Foundation
import UIKit
struct Colors{
    
    static let brightOrange   = UIColor(red: 255.0/255.0, green: 69.0/255.0, blue:0.0/255.0, alpha:10.0)
      static let Orange   = UIColor(red: 255.0/255.0, green: 175/255.0, blue:72/255.0, alpha:4.0)
      
    
}
