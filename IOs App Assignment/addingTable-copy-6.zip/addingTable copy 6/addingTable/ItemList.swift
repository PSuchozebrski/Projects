//
//  Notes.swift
//  addingTable
//
//  Created by Piotr Suchozebrski on 20/11/2018.
//  Copyright © 2018 Piotr Suchozebrski. All rights reserved.
//

import Foundation



struct ItemList: Codable {
    let translation: String
    let itemDescription: String
}
